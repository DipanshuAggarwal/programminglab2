﻿printfn"Part 1:"
type Coach = { Name: string; FormerPlayer: bool }
type Stats = { Wins: int; Losses: int }
type Team = { Name: string; Coach: Coach; Stats: Stats }

let teams = [
    { Name = "CSK"; Coach = { Name = "MS Dhoni"; FormerPlayer = true }; Stats = { Wins = 50; Losses = 32 } }
    { Name = "RCB"; Coach = { Name = "Virat Kohli"; FormerPlayer = true }; Stats = { Wins = 44; Losses = 38 } }
    { Name = "Punjab Kings"; Coach = { Name = "KL Rahul"; FormerPlayer = false }; Stats = { Wins = 45; Losses = 60 } }
    { Name = "MI"; Coach = { Name = "Shikhar Dhawan"; FormerPlayer = true }; Stats = { Wins = 55; Losses = 27 } }
    { Name = "RR"; Coach = { Name = "Sanju Samson"; FormerPlayer = false }; Stats = { Wins = 40; Losses = 45 } }
]

let successfulTeams = teams |> List.filter (fun team -> team.Stats.Wins > team.Stats.Losses)

let successPercentages = 
    teams 
    |> List.map (fun team -> team.Name, (float team.Stats.Wins / float (team.Stats.Wins + team.Stats.Losses)) * 100.0)

printfn "Successful Teams: %A" (successfulTeams |> List.map (fun team -> team.Name))
printfn "\nSuccess Percentages:"
successPercentages |> List.iter (fun (name, percentage) -> printfn "%s:  %.2f%%" name percentage )

printfn"\nPart 2:"

type Cuisine = 
    | Korean 
    | Turkish

type MovieType = 
    | Regular 
    | IMAX 
    | DBOX 
    | RegularWithSnacks 
    | IMAXWithSnacks 
    | DBOXWithSnacks

type Activity = 
    | BoardGame
    | Chill
    | Movie of MovieType
    | Restaurant of Cuisine
    | LongDrive of int * float

let calculateBudget activity = 
    match activity with
    | BoardGame -> 0.0
    | Chill -> 0.0
    | Movie movieType ->
        match movieType with
        | Regular -> 12.0
        | IMAX -> 17.0
        | DBOX -> 20.0
        | RegularWithSnacks -> 12.0 + 5.0
        | IMAXWithSnacks -> 17.0 + 5.0
        | DBOXWithSnacks -> 20.0 + 5.0
    | Restaurant cuisine ->
        match cuisine with
        | Korean -> 70.0
        | Turkish -> 65.0
    | LongDrive (kilometres, fuelCostPerKilometre) -> 
        float kilometres * fuelCostPerKilometre

let activities = [
    Movie IMAXWithSnacks
    Restaurant Turkish
    LongDrive (145, 1.5)
]

let activityBudgets = activities |> List.map calculateBudget

let totalBudget = activityBudgets |> List.sum

printfn "\nIndividual Activity Budgets:"
activities
|> List.iteri (fun index activity -> 
    printfn "Activity-%d: %.2f CAD" (index + 1) (calculateBudget activity))

printfn "\nTotal Budget: %.2f CAD Activity: %A" totalBudget activities

